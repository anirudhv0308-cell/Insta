# Instagram Focus (prototype)

This is an Android Studio source project for a distraction-reduced Instagram launcher.

## What it does
- Shows a minimal home screen with Messages, Stories, and Accounts.
- Opens the corresponding Instagram web pages in the device's browser.
- Does not ask for or store Instagram passwords.

## Important limitations
This is a prototype, not a compiled APK. Instagram controls which features work on its website and may require the official app or change its web interface. In particular, Stories and DMs may not be fully usable in a third-party browser. This project does not bypass Instagram restrictions.

## Build
1. Install Android Studio on a computer.
2. Open this folder as a project.
3. Let Gradle sync.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will show the APK location when the build finishes.

The project uses Android Gradle Plugin 8.6.1 and Gradle 8.7. If Android Studio prompts you to update versions, use its recommended compatible versions.
